# Build Go Digital ReadyDocs APK

## GitHub Actions
This project includes `.github/workflows/android-build.yml`.

1. Put this project in a GitHub repository.
2. Open **Actions > Build Android APK**.
3. Choose **Run workflow**.
4. Download the artifact named **GoDigital-ReadyDocs-Android**.

The workflow uses Flutter 3.47.5 stable, generates the missing Android platform scaffolding, restores the app's custom Android manifest, gets packages, analyzes the project, builds a release APK, and uploads the APK plus SHA-256 checksum.

## Local build
With Flutter installed:

```bash
./tool/build_android.sh
```

Output:

`dist/GoDigital-ReadyDocs-v0.1.apk`

## Signing note
This starter build is intended for direct internal testing. Before production distribution, configure a private release signing key and keep it out of the source repository.
