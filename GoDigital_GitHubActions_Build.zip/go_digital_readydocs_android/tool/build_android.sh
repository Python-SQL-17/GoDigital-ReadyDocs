#!/usr/bin/env bash
set -euo pipefail

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK is required. Install Flutter 3.47.5 or newer stable first." >&2
  exit 1
fi

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

MANIFEST_BACKUP="$(mktemp)"
cp android/app/src/main/AndroidManifest.xml "$MANIFEST_BACKUP"
flutter create . --platforms=android --org com.godigitalservices --project-name go_digital_readydocs
cp "$MANIFEST_BACKUP" android/app/src/main/AndroidManifest.xml
rm -f "$MANIFEST_BACKUP"

flutter pub get
flutter analyze --no-fatal-infos
flutter build apk --release
mkdir -p dist
cp build/app/outputs/flutter-apk/app-release.apk dist/GoDigital-ReadyDocs-v0.1.apk
sha256sum dist/GoDigital-ReadyDocs-v0.1.apk > dist/GoDigital-ReadyDocs-v0.1.apk.sha256

echo "Built: $ROOT/dist/GoDigital-ReadyDocs-v0.1.apk"
