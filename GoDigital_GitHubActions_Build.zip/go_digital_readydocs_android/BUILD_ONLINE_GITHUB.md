# Build the GoDigital APK online with GitHub Actions

This package is configured to build on GitHub Actions instead of FlutLab.

## Build

1. Create or open a GitHub repository.
2. Upload **the contents of this project folder** to the repository root. The `.github` folder must be included.
3. Open the repository's **Actions** tab.
4. Select **Build GoDigital Android APK**.
5. Select **Run workflow**.
6. When the run finishes, open it and download the artifact **GoDigital-ReadyDocs-APK**.
7. Inside the artifact ZIP is `GoDigital-ReadyDocs-v0.1.apk`.

The workflow installs Java and the latest stable Flutter SDK in the cloud, generates the Android platform files, downloads Flutter packages, builds a release APK, and uploads the APK as a GitHub artifact.
