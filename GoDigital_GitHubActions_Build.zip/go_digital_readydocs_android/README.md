# Go Digital Services - ReadyDocs Android

Offline-first Android document preparation app for CSC work.

## Included in this first source build

- New Customer workflow with **two folder naming options**:
  1. Manual folder name
  2. Detect first/last name from Aadhaar/PAN image using on-device OCR
- Creates `ORIGINALS`, `PROCESSED`, and `READY_TO_UPLOAD` folders.
- Creates `Customer_Details.txt` and `Customer_Details.json`.
- Aadhaar is **masked by default** in the saved customer summary.
- Offline OCR scaffolding for name, Aadhaar, PAN, DOB, EPIC, gender, father name/address candidates.
- Document image import.
- EXIF orientation normalization, white-border trim, brightness/contrast enhancement, sharpening.
- JPEG size-rule loop.
- Multi-image PDF creation.
- Portal preset rules loaded from editable JSON.
- Aaple Sarkar / Sarathi / PAN starter presets.
- Local Wi-Fi transfer protocol scaffold for the future Windows `Documents Create` module.

## Production features still to finish before CSC deployment

- Robust document-edge detection + perspective correction (OpenCV).
- Dedicated Photo Maker with face-centered crop preview.
- Dedicated Signature Maker with white-background cleanup.
- PDF compression loop that guarantees exact portal KB range.
- Editable portal-rule UI and service-specific required-document checklists.
- Stronger Aadhaar/PAN/Voter parsers with Marathi/Hindi OCR.
- QR LAN pairing + authenticated encryption + checksum verification.
- Customer browser, search, retention policy and encrypted local database.
- Full automated tests on representative documents.

## Build

This environment does not contain Flutter/Android SDK build tooling, so the ZIP contains **source code**, not a compiled APK.

On a development PC:

```bash
flutter create . --platforms=android
flutter pub get
flutter run
```

Then build:

```bash
flutter build apk --release
```

Before real customer use, complete and test the production items above.

## GitHub Actions build

A ready-to-run Android build workflow is included at `.github/workflows/android-build.yml`. It uses Flutter 3.47.5 stable and uploads `GoDigital-ReadyDocs-v0.1.apk` as a workflow artifact. See `BUILD_NOW.md`.
