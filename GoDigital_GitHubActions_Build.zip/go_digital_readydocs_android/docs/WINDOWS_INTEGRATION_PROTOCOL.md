# Windows Documents Create integration

The Android app reserves TCP port `45871` for same-LAN transfer.

Initial frame:

```json
{"pairCode":"123456","name":"Customer_Name.zip","bytes":12345}
```

A newline follows the JSON header, followed by raw ZIP bytes.

The existing Go Digital Windows application's new **Documents Create** section should implement the corresponding receiver/sender. For production, replace the simple pairing-code transport with authenticated encrypted session keys and SHA-256 integrity verification.
