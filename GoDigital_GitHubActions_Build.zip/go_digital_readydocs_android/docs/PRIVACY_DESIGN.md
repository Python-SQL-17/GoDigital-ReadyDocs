# Privacy design

- Offline-first document processing.
- No analytics SDK.
- No advertising SDK.
- No cloud upload in the document processor.
- Aadhaar masked in summaries by default.
- Operator confirmation required for OCR fields.
- Real deployment should encrypt the customer database/folders and include automatic retention/deletion settings.
