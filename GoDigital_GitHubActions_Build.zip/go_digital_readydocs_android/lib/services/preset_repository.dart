import 'dart:convert';
import 'package:flutter/services.dart';
import '../models/portal_preset.dart';

class PresetRepository {
  Future<List<PortalPreset>> load() async {
    final raw = await rootBundle.loadString('assets/portal_presets.json');
    final data = jsonDecode(raw) as List;
    return data.map((e) => PortalPreset.fromJson(e)).toList();
  }
}
