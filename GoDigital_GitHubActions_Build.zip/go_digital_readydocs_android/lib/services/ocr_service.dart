import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import '../models/customer_details.dart';

class OcrService {
  final TextRecognizer _recognizer = TextRecognizer(script: TextRecognitionScript.latin);

  Future<String> recognize(String imagePath) async {
    final input = InputImage.fromFilePath(imagePath);
    final result = await _recognizer.processImage(input);
    return result.text;
  }

  CustomerDetails extract(String text) {
    final lines = text
        .split(RegExp(r'\r?\n'))
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();
    final out = CustomerDetails();

    final aadhaar = RegExp(r'\b(\d{4})\s?(\d{4})\s?(\d{4})\b').firstMatch(text);
    if (aadhaar != null) {
      out.aadhaarNumber = '${aadhaar.group(1)}${aadhaar.group(2)}${aadhaar.group(3)}';
    }

    final pan = RegExp(r'\b[A-Z]{5}[0-9]{4}[A-Z]\b').firstMatch(text.toUpperCase());
    if (pan != null) out.panNumber = pan.group(0)!;

    final epic = RegExp(r'\b[A-Z]{3}[0-9]{7}\b').firstMatch(text.toUpperCase());
    if (epic != null) out.voterNumber = epic.group(0)!;

    final dob = RegExp(r'\b\d{2}[/-]\d{2}[/-]\d{4}\b').firstMatch(text);
    if (dob != null) {
      out.aadhaarDob = dob.group(0)!;
      out.panDob = dob.group(0)!;
    }

    final upper = text.toUpperCase();
    if (upper.contains('FEMALE')) out.gender = 'Female';
    if (upper.contains('MALE') && !upper.contains('FEMALE')) out.gender = 'Male';

    // Conservative name candidate: operator must confirm/edit before saving.
    final nameCandidates = lines.where((l) {
      final cleaned = l.replaceAll(RegExp(r'[^A-Za-z .]'), '').trim();
      final words = cleaned.split(RegExp(r'\s+'));
      if (words.length < 2 || words.length > 5) return false;
      final bad = RegExp(r'government|india|income|tax|date|birth|male|female|address|father|elector|authority', caseSensitive: false);
      return cleaned.length >= 6 && !bad.hasMatch(cleaned);
    }).toList();

    if (nameCandidates.isNotEmpty) {
      out.fullName = nameCandidates.first.replaceAll(RegExp(r'\s+'), ' ').trim();
      final p = out.fullName.split(' ');
      out.firstName = p.first;
      if (p.length == 2) {
        out.lastName = p.last;
      } else if (p.length > 2) {
        out.middleName = p.sublist(1, p.length - 1).join(' ');
        out.lastName = p.last;
      }
    }

    final fatherIndex = lines.indexWhere((l) => RegExp(r'father', caseSensitive: false).hasMatch(l));
    if (fatherIndex >= 0 && fatherIndex + 1 < lines.length) {
      out.fatherName = lines[fatherIndex + 1];
    }

    final addressIndex = lines.indexWhere((l) => RegExp(r'address', caseSensitive: false).hasMatch(l));
    if (addressIndex >= 0) {
      out.address = lines.skip(addressIndex + 1).take(5).join(', ');
    }
    return out;
  }

  Future<void> dispose() => _recognizer.close();
}
