import 'dart:io';
import 'package:pdf/widgets.dart' as pw;

class PdfService {
  Future<File> imagesToPdf(List<String> imagePaths, File out) async {
    final doc = pw.Document();
    for (final path in imagePaths) {
      final bytes = await File(path).readAsBytes();
      final image = pw.MemoryImage(bytes);
      doc.addPage(pw.Page(
        margin: const pw.EdgeInsets.all(12),
        build: (_) => pw.Center(child: pw.Image(image, fit: pw.BoxFit.contain)),
      ));
    }
    await out.writeAsBytes(await doc.save(), flush: true);
    return out;
  }
}
