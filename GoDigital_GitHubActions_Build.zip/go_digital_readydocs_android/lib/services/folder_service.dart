import 'dart:convert';
import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import '../models/customer_details.dart';

class FolderService {
  Future<Directory> appRoot() async {
    final base = await getApplicationDocumentsDirectory();
    final root = Directory(p.join(base.path, 'GoDigitalServices', 'Customers'));
    await root.create(recursive: true);
    return root;
  }

  String sanitize(String name) {
    var s = name.trim().replaceAll(RegExp(r'[^A-Za-z0-9 _.-]'), '');
    s = s.replaceAll(RegExp(r'\s+'), '_');
    return s.isEmpty ? 'Customer' : s;
  }

  Future<Directory> createCustomerFolder(String requestedName) async {
    final root = await appRoot();
    final base = sanitize(requestedName);
    var target = Directory(p.join(root.path, base));
    var i = 2;
    while (await target.exists()) {
      target = Directory(p.join(root.path, '${base}_${i.toString().padLeft(2, '0')}'));
      i++;
    }
    await target.create(recursive: true);
    for (final child in ['ORIGINALS', 'PROCESSED', 'READY_TO_UPLOAD']) {
      await Directory(p.join(target.path, child)).create(recursive: true);
    }
    return target;
  }

  Future<void> writeCustomerDetails(Directory customer, CustomerDetails d,
      {bool includeFullAadhaar = false}) async {
    final jsonFile = File(p.join(customer.path, 'Customer_Details.json'));
    await jsonFile.writeAsString(const JsonEncoder.withIndent('  ').convert(d.toJson(includeFullAadhaar: includeFullAadhaar)));

    final txt = StringBuffer()
      ..writeln('GO DIGITAL SERVICES')
      ..writeln('CUSTOMER DOCUMENT DETAILS')
      ..writeln('----------------------------------------')
      ..writeln('Full Name       : ${d.fullName}')
      ..writeln('First Name      : ${d.firstName}')
      ..writeln('Middle Name     : ${d.middleName}')
      ..writeln('Last Name       : ${d.lastName}')
      ..writeln('Mobile Number   : ${d.mobile}')
      ..writeln('Aadhaar Number  : ${includeFullAadhaar ? d.aadhaarNumber : d.maskedAadhaar}')
      ..writeln('Aadhaar DOB     : ${d.aadhaarDob}')
      ..writeln('PAN Number      : ${d.panNumber}')
      ..writeln('PAN DOB         : ${d.panDob}')
      ..writeln("Father's Name   : ${d.fatherName}")
      ..writeln('Voter / EPIC No : ${d.voterNumber}')
      ..writeln('Gender           : ${d.gender}')
      ..writeln('Address          : ${d.address}')
      ..writeln('----------------------------------------')
      ..writeln('OCR details must be verified by the operator before portal submission.');
    await File(p.join(customer.path, 'Customer_Details.txt')).writeAsString(txt.toString());
  }
}
