import 'dart:io';
import 'package:image/image.dart' as im;
import '../models/portal_preset.dart';

class ImageProcessor {
  Future<im.Image> loadAndNormalize(String path) async {
    final bytes = await File(path).readAsBytes();
    var img = im.decodeImage(bytes);
    if (img == null) throw Exception('Unsupported image');
    img = im.bakeOrientation(img);
    return img;
  }

  im.Image enhanceDocument(im.Image src) {
    var x = im.adjustColor(src, brightness: 1.08, contrast: 1.15);
    x = im.convolution(x, filter: const [0, -1, 0, -1, 5, -1, 0, -1, 0], div: 1);
    return x;
  }

  im.Image rotate90(im.Image src) => im.copyRotate(src, angle: 90);

  im.Image cropWhiteBorder(im.Image src) {
    int left = src.width, right = 0, top = src.height, bottom = 0;
    bool found = false;
    for (var y = 0; y < src.height; y += 2) {
      for (var x = 0; x < src.width; x += 2) {
        final px = src.getPixel(x, y);
        final lum = (px.r + px.g + px.b) / 3;
        if (lum < 235) {
          found = true;
          if (x < left) left = x;
          if (x > right) right = x;
          if (y < top) top = y;
          if (y > bottom) bottom = y;
        }
      }
    }
    if (!found || right <= left || bottom <= top) return src;
    const pad = 12;
    left = (left - pad).clamp(0, src.width - 1).toInt();
    top = (top - pad).clamp(0, src.height - 1).toInt();
    right = (right + pad).clamp(0, src.width - 1).toInt();
    bottom = (bottom + pad).clamp(0, src.height - 1).toInt();
    return im.copyCrop(src, x: left, y: top, width: right - left + 1, height: bottom - top + 1);
  }

  im.Image fitPhoto(im.Image src, SizeRule rule) {
    if (rule.width == null) return src;
    final targetH = rule.height ?? rule.heightMin;
    if (targetH == null) return im.copyResize(src, width: rule.width);
    final targetRatio = rule.width! / targetH;
    final current = src.width / src.height;
    im.Image cropped = src;
    if (current > targetRatio) {
      final w = (src.height * targetRatio).round();
      cropped = im.copyCrop(src, x: (src.width - w) ~/ 2, y: 0, width: w, height: src.height);
    } else if (current < targetRatio) {
      final h = (src.width / targetRatio).round();
      final y = ((src.height - h) * 0.35).round().clamp(0, src.height - h).toInt();
      cropped = im.copyCrop(src, x: 0, y: y, width: src.width, height: h);
    }
    return im.copyResize(cropped, width: rule.width!, height: targetH);
  }

  Future<File> saveJpegWithinRule(im.Image src, File out, SizeRule rule) async {
    for (final quality in [92, 88, 84, 80, 76, 72, 68, 64, 60, 55, 50, 45, 40, 35, 30]) {
      final bytes = im.encodeJpg(src, quality: quality);
      final kb = bytes.length / 1024.0;
      if ((rule.maxKb == null || kb <= rule.maxKb!) && (rule.minKb == null || kb >= rule.minKb!)) {
        await out.writeAsBytes(bytes, flush: true);
        return out;
      }
    }
    await out.writeAsBytes(im.encodeJpg(src, quality: 45), flush: true);
    return out;
  }
}
