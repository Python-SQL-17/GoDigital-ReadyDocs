import 'dart:io';
import 'package:image/image.dart' as im;
import '../models/portal_preset.dart';

class ValidationResult {
  final bool ok;
  final List<String> checks;
  const ValidationResult(this.ok, this.checks);
}

class ValidatorService {
  Future<ValidationResult> validateImage(File file, SizeRule? rule) async {
    final checks = <String>[];
    if (rule == null) return ValidationResult(true, ['No preset limits configured']);
    final bytes = await file.readAsBytes();
    final kb = bytes.length / 1024.0;
    final img = im.decodeImage(bytes);
    var ok = true;
    if (rule.minKb != null && kb < rule.minKb!) { ok = false; checks.add('Too small: ${kb.toStringAsFixed(1)} KB'); }
    if (rule.maxKb != null && kb > rule.maxKb!) { ok = false; checks.add('Too large: ${kb.toStringAsFixed(1)} KB'); }
    if (img != null && rule.width != null && img.width != rule.width) { ok = false; checks.add('Width ${img.width}px; required ${rule.width}px'); }
    if (img != null && rule.height != null && img.height != rule.height) { ok = false; checks.add('Height ${img.height}px; required ${rule.height}px'); }
    if (img != null && rule.heightMin != null && img.height < rule.heightMin!) { ok = false; checks.add('Height below ${rule.heightMin}px'); }
    if (img != null && rule.heightMax != null && img.height > rule.heightMax!) { ok = false; checks.add('Height above ${rule.heightMax}px'); }
    if (ok) checks.add('READY');
    return ValidationResult(ok, checks);
  }
}
