import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:archive/archive_io.dart';

class WifiShareService {
  static const int port = 45871;

  String makePairCode() => (100000 + Random.secure().nextInt(900000)).toString();

  Future<File> zipFolder(Directory folder, File out) async {
    final encoder = ZipFileEncoder()..create(out.path);
    encoder.addDirectory(folder);
    encoder.close();
    return out;
  }

  Future<void> sendZip({required String host, required String pairCode, required File zip}) async {
    final socket = await Socket.connect(host, port, timeout: const Duration(seconds: 8));
    final bytes = await zip.readAsBytes();
    final header = jsonEncode({'pairCode': pairCode, 'name': zip.uri.pathSegments.last, 'bytes': bytes.length});
    socket.add(utf8.encode('$header\n'));
    socket.add(bytes);
    await socket.flush();
    await socket.close();
  }

  Future<ServerSocket> startReceiver({required String pairCode, required Directory destination}) async {
    final server = await ServerSocket.bind(InternetAddress.anyIPv4, port);
    server.listen((socket) async {
      final builder = BytesBuilder();
      await for (final chunk in socket) {
        builder.add(chunk);
      }
      final all = builder.takeBytes();
      final nl = all.indexOf(10);
      if (nl <= 0) return;
      final header = jsonDecode(utf8.decode(all.sublist(0, nl))) as Map<String, dynamic>;
      if (header['pairCode'] != pairCode) return;
      final filename = (header['name'] as String).replaceAll(RegExp(r'[^A-Za-z0-9_.-]'), '_');
      await File('${destination.path}/$filename').writeAsBytes(all.sublist(nl + 1), flush: true);
    });
    return server;
  }
}
