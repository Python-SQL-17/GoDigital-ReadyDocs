class CustomerDetails {
  String fullName;
  String firstName;
  String middleName;
  String lastName;
  String mobile;
  String aadhaarNumber;
  String aadhaarDob;
  String panNumber;
  String panDob;
  String address;
  String fatherName;
  String voterNumber;
  String gender;

  CustomerDetails({
    this.fullName = '',
    this.firstName = '',
    this.middleName = '',
    this.lastName = '',
    this.mobile = '',
    this.aadhaarNumber = '',
    this.aadhaarDob = '',
    this.panNumber = '',
    this.panDob = '',
    this.address = '',
    this.fatherName = '',
    this.voterNumber = '',
    this.gender = '',
  });

  String get maskedAadhaar {
    final d = aadhaarNumber.replaceAll(RegExp(r'\D'), '');
    if (d.length != 12) return '';
    return 'XXXX XXXX ${d.substring(8)}';
  }

  Map<String, dynamic> toJson({bool includeFullAadhaar = false}) => {
        'fullName': fullName,
        'firstName': firstName,
        'middleName': middleName,
        'lastName': lastName,
        'mobile': mobile,
        'aadhaar': includeFullAadhaar ? aadhaarNumber : maskedAadhaar,
        'aadhaarDob': aadhaarDob,
        'pan': panNumber,
        'panDob': panDob,
        'address': address,
        'fatherName': fatherName,
        'voterNumber': voterNumber,
        'gender': gender,
      };
}
