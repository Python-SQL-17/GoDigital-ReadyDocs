class SizeRule {
  final String? format;
  final List<String>? formats;
  final int? minKb;
  final int? maxKb;
  final int? width;
  final int? height;
  final int? heightMin;
  final int? heightMax;
  final double? physicalWidthCm;
  final double? physicalHeightCm;

  const SizeRule({
    this.format,
    this.formats,
    this.minKb,
    this.maxKb,
    this.width,
    this.height,
    this.heightMin,
    this.heightMax,
    this.physicalWidthCm,
    this.physicalHeightCm,
  });

  factory SizeRule.fromJson(Map<String, dynamic> j) => SizeRule(
        format: j['format'] as String?,
        formats: (j['formats'] as List?)?.cast<String>(),
        minKb: j['minKb'] as int?,
        maxKb: j['maxKb'] as int?,
        width: j['width'] as int?,
        height: j['height'] as int?,
        heightMin: j['heightMin'] as int?,
        heightMax: j['heightMax'] as int?,
        physicalWidthCm: (j['physicalWidthCm'] as num?)?.toDouble(),
        physicalHeightCm: (j['physicalHeightCm'] as num?)?.toDouble(),
      );
}

class PortalPreset {
  final String id;
  final String name;
  final String? verifiedDate;
  final SizeRule? photo;
  final SizeRule? document;
  final SizeRule? signature;
  final String notes;

  const PortalPreset({
    required this.id,
    required this.name,
    this.verifiedDate,
    this.photo,
    this.document,
    this.signature,
    required this.notes,
  });

  factory PortalPreset.fromJson(Map<String, dynamic> j) => PortalPreset(
        id: j['id'] as String,
        name: j['name'] as String,
        verifiedDate: j['verifiedDate'] as String?,
        photo: j['photo'] == null ? null : SizeRule.fromJson(j['photo']),
        document: j['document'] == null ? null : SizeRule.fromJson(j['document']),
        signature: j['signature'] == null ? null : SizeRule.fromJson(j['signature']),
        notes: (j['notes'] ?? '') as String,
      );
}
