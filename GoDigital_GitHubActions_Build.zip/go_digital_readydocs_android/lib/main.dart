import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const GoDigitalReadyDocsApp());
}

class GoDigitalReadyDocsApp extends StatelessWidget {
  const GoDigitalReadyDocsApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Go Digital ReadyDocs',
        theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
        home: const HomeScreen(),
      );
}
