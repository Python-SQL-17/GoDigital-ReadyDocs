import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models/customer_details.dart';
import '../services/folder_service.dart';
import '../services/ocr_service.dart';
import 'job_screen.dart';

class NewCustomerScreen extends StatefulWidget {
  const NewCustomerScreen({super.key});
  @override
  State<NewCustomerScreen> createState() => _NewCustomerScreenState();
}

class _NewCustomerScreenState extends State<NewCustomerScreen> {
  final name = TextEditingController();
  final mobile = TextEditingController();
  bool working = false;
  final details = CustomerDetails();

  Future<void> detectName() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (picked == null) return;
    setState(() => working = true);
    try {
      final ocr = OcrService();
      final text = await ocr.recognize(picked.path);
      final d = ocr.extract(text);
      await ocr.dispose();
      details
        ..fullName = d.fullName
        ..firstName = d.firstName
        ..middleName = d.middleName
        ..lastName = d.lastName
        ..aadhaarNumber = d.aadhaarNumber
        ..aadhaarDob = d.aadhaarDob
        ..panNumber = d.panNumber
        ..panDob = d.panDob
        ..address = d.address
        ..fatherName = d.fatherName
        ..voterNumber = d.voterNumber
        ..gender = d.gender;
      final suggested = [d.firstName, d.lastName].where((e) => e.isNotEmpty).join('_');
      name.text = suggested.isEmpty ? d.fullName.replaceAll(' ', '_') : suggested;
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Name detected. Please verify before creating folder.')));
    } finally {
      if (mounted) setState(() => working = false);
    }
  }

  Future<void> create() async {
    if (name.text.trim().isEmpty) return;
    setState(() => working = true);
    details.mobile = mobile.text.trim();
    final folder = await FolderService().createCustomerFolder(name.text.trim());
    await FolderService().writeCustomerDetails(folder, details, includeFullAadhaar: false);
    if (!mounted) return;
    setState(() => working = false);
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => JobScreen(customerFolder: Directory(folder.path), details: details)));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('New Customer')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          const Text('Choose folder naming method', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          TextField(controller: name, decoration: const InputDecoration(labelText: '1. Enter folder name manually', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          OutlinedButton.icon(onPressed: working ? null : detectName, icon: const Icon(Icons.document_scanner), label: const Text('2. Detect First + Last Name from Aadhaar / PAN')),
          const SizedBox(height: 12),
          TextField(controller: mobile, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Mobile number (optional)', border: OutlineInputBorder())),
          const SizedBox(height: 18),
          FilledButton.icon(onPressed: working ? null : create, icon: const Icon(Icons.create_new_folder), label: Text(working ? 'Working...' : 'Create Customer Folder')),
          const SizedBox(height: 12),
          const Text('OCR is offline/on-device. Detected names and document fields must be confirmed by the operator.'),
        ]),
      );
}
