import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import '../services/wifi_share_service.dart';

class WifiShareScreen extends StatefulWidget {
  const WifiShareScreen({super.key});
  @override
  State<WifiShareScreen> createState() => _WifiShareScreenState();
}

class _WifiShareScreenState extends State<WifiShareScreen> {
  final host = TextEditingController();
  final code = TextEditingController();
  ServerSocket? server;
  String status = 'Use the same Wi-Fi network or phone hotspot.';

  Future<void> startReceiver() async {
    final service = WifiShareService();
    final c = service.makePairCode();
    code.text = c;
    final dest = Directory('${(await getApplicationDocumentsDirectory()).path}/GoDigitalServices/Incoming');
    await dest.create(recursive: true);
    server = await service.startReceiver(pairCode: c, destination: dest);
    setState(() => status = 'Receiver started on port ${WifiShareService.port}. Pair code: $c');
  }

  @override
  void dispose() { server?.close(); host.dispose(); code.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Local Wi-Fi Share')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          const Text('No internet or cloud required. Pair the Windows Documents Create module on the same LAN.'),
          const SizedBox(height: 16),
          FilledButton.icon(onPressed: startReceiver, icon: const Icon(Icons.wifi), label: const Text('Start Receive Mode')),
          const SizedBox(height: 12),
          TextField(controller: code, readOnly: true, decoration: const InputDecoration(labelText: '6-digit pairing code', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: host, decoration: const InputDecoration(labelText: 'Desktop IP for Send mode', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          Text(status),
          const SizedBox(height: 12),
          const Text('Production build: device discovery, QR pairing, encrypted authenticated transfer and checksum verification should be enabled before handling real customer folders.'),
        ]),
      );
}
