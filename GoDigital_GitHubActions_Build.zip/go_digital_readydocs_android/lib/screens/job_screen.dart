import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import '../models/customer_details.dart';
import '../models/portal_preset.dart';
import '../services/image_processor.dart';
import '../services/pdf_service.dart';
import '../services/preset_repository.dart';
import '../services/validator_service.dart';

class JobScreen extends StatefulWidget {
  final Directory customerFolder;
  final CustomerDetails details;
  const JobScreen({super.key, required this.customerFolder, required this.details});
  @override
  State<JobScreen> createState() => _JobScreenState();
}

class _JobScreenState extends State<JobScreen> {
  List<PortalPreset> presets = [];
  PortalPreset? selected;
  final imported = <String>[];
  String status = 'Select service and import documents.';
  bool busy = false;

  @override
  void initState() {
    super.initState();
    PresetRepository().load().then((v) => setState(() { presets = v; selected = v.first; }));
  }

  Future<void> importFiles() async {
    final result = await FilePicker.platform.pickFiles(allowMultiple: true, type: FileType.image);
    if (result == null) return;
    setState(() => imported.addAll(result.paths.whereType<String>()));
  }

  Future<void> processAll() async {
    if (selected == null || imported.isEmpty) return;
    setState(() { busy = true; status = 'Processing...'; });
    final procDir = Directory(p.join(widget.customerFolder.path, 'PROCESSED'));
    final ready = Directory(p.join(widget.customerFolder.path, 'READY_TO_UPLOAD'));
    await procDir.create(recursive: true); await ready.create(recursive: true);
    final processor = ImageProcessor();
    final processedImages = <String>[];
    for (var i = 0; i < imported.length; i++) {
      var img = await processor.loadAndNormalize(imported[i]);
      img = processor.cropWhiteBorder(img);
      img = processor.enhanceDocument(img);
      final out = File(p.join(procDir.path, 'Document_${i + 1}.jpg'));
      final rule = selected!.document ?? const SizeRule(format: 'jpg');
      await processor.saveJpegWithinRule(img, out, rule);
      processedImages.add(out.path);
    }
    final pdf = File(p.join(ready.path, 'Documents_Merged.pdf'));
    await PdfService().imagesToPdf(processedImages, pdf);
    final first = File(processedImages.first);
    final vr = await ValidatorService().validateImage(first, selected!.document);
    setState(() { busy = false; status = 'Created ${processedImages.length} enhanced JPG(s) + merged PDF. First image check: ${vr.checks.join(', ')}'; });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text('Documents Create - ${p.basename(widget.customerFolder.path)}')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          DropdownButtonFormField<PortalPreset>(
            value: selected,
            decoration: const InputDecoration(labelText: 'Service / Portal Preset', border: OutlineInputBorder()),
            items: presets.map((e) => DropdownMenuItem(value: e, child: Text(e.name))).toList(),
            onChanged: (v) => setState(() => selected = v),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(onPressed: busy ? null : importFiles, icon: const Icon(Icons.add_photo_alternate), label: const Text('Import Document Images')),
          const SizedBox(height: 8),
          Text('${imported.length} image(s) selected'),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: busy ? null : processAll, icon: const Icon(Icons.auto_fix_high), label: Text(busy ? 'Processing...' : 'PROCESS ALL - READY TO UPLOAD')),
          const SizedBox(height: 12),
          Text(status),
          const Divider(height: 28),
          const Text('Photo Maker and Signature Maker use the same processing engine and portal preset rules; dedicated capture screens are the next UI module.'),
        ]),
      );
}
