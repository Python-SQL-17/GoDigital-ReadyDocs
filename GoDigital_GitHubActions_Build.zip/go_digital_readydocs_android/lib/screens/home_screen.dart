import 'package:flutter/material.dart';
import 'new_customer_screen.dart';
import 'wifi_share_screen.dart';
import 'presets_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      ('New Customer', Icons.person_add_alt_1, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NewCustomerScreen()))),
      ('Process Documents', Icons.document_scanner, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NewCustomerScreen()))),
      ('Ready To Upload', Icons.cloud_done_outlined, () => _info(context, 'Ready folders are created inside each customer job.')),
      ('Share With PC', Icons.wifi_tethering, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WifiShareScreen()))),
      ('Receive Files', Icons.download_for_offline, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WifiShareScreen()))),
      ('Portal Rules', Icons.rule_folder, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PresetsScreen()))),
      ('Customers', Icons.people_alt_outlined, () => _info(context, 'Customer browser is included in the next UI iteration.')),
      ('Settings', Icons.settings, () => _info(context, 'Privacy, Aadhaar masking, retention and custom presets will live here.')),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Go Digital Services - ReadyDocs')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: GridView.count(
          crossAxisCount: 2,
          childAspectRatio: 1.15,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          children: [for (final x in items) _Tile(title: x.$1, icon: x.$2, onTap: x.$3)],
        ),
      ),
    );
  }

  static void _info(BuildContext context, String message) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
}

class _Tile extends StatelessWidget {
  final String title;
  final IconData icon;
  final VoidCallback onTap;
  const _Tile({required this.title, required this.icon, required this.onTap});
  @override
  Widget build(BuildContext context) => Card(
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, size: 42), const SizedBox(height: 10), Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700))]),
          ),
        ),
      );
}
