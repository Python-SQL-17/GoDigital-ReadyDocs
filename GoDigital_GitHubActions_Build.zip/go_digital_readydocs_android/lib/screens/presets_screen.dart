import 'package:flutter/material.dart';
import '../models/portal_preset.dart';
import '../services/preset_repository.dart';

class PresetsScreen extends StatelessWidget {
  const PresetsScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Portal Rules')),
        body: FutureBuilder<List<PortalPreset>>(
          future: PresetRepository().load(),
          builder: (_, snap) {
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            return ListView(children: snap.data!.map((p) => ListTile(
              title: Text(p.name),
              subtitle: Text('Verified: ${p.verifiedDate ?? 'Operator-defined'}\n${p.notes}'),
              isThreeLine: true,
              trailing: const Icon(Icons.edit_note),
            )).toList());
          },
        ),
      );
}
